﻿// Copyright lurongjiu 2025. All Rights Reserved.

#include "ImageCommentActions.h"

#define LOCTEXT_NAMESPACE "FImageCommentPluginModule"

void ImageCommentActions::RegisterCommands()
{
	UI_COMMAND(CreateImageComment, "Create Image Comment", "Create an image comment box", EUserInterfaceActionType::Button, FInputChord(EKeys::V) );
}

#undef LOCTEXT_NAMESPACE