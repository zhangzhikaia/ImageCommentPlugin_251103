// Copyright lurongjiu 2025. All Rights Reserved.

#include "ImageCommentPlugin.h"
#include "ImageCommentActions.h"
#include "BlueprintEditorModule.h"
#include "DebugHelper_ImageComment.h"
//#include "BlueprintEditor.h"
#include "EdGraphNode_ImageComment.h"
#include "FEdGraphSchemaAction_AddImageComment.h"
#include "EdGraph/EdGraphSchema.h"
#include "ImageCommentUtilities.h"
#include "IMaterialEditor.h"
#include "MaterialEditorModule.h"
#include "MaterialGraph/MaterialGraph.h"
#include "Materials/MaterialExpressionComment.h"
#include "NiagaraEditorModule.h"
#include "NiagaraSystem.h"
//
#include "ViewModels/NiagaraOverviewGraphViewModel.h"
#include "ViewModels/NiagaraSystemViewModel.h"


#define LOCTEXT_NAMESPACE "FImageCommentPluginModule"

void FImageCommentPluginModule::StartupModule()
{
	//注册调出image comment快捷键(不是绑定和执行事件
	ImageCommentActions::Register();
	
	//绑定按键实际在图表生效和执行事件
	BindAddImageCommentAction_K2();
	
	BindAddImageCommentAction_Material();

	BindAddImageCommentAction_NiagaraSystem();
	
}

void FImageCommentPluginModule::ShutdownModule()
{
	ImageCommentActions::Unregister();
}

void FImageCommentPluginModule::BindAddImageCommentAction_K2()
{
	// 获取蓝图编辑器模块
	FBlueprintEditorModule& BlueprintEditorModule = FModuleManager::LoadModuleChecked<FBlueprintEditorModule>("Kismet");
	// 获取共享命令列表
	TSharedRef<FUICommandList> SharedCommands = BlueprintEditorModule.GetsSharedBlueprintEditorCommands();

	// 直接绑定命令到共享命令列表
	SharedCommands->MapAction(
		ImageCommentActions::Get().CreateImageComment,
		FExecuteAction::CreateStatic(&FImageCommentPluginModule::CreateImageComment_K2)
	);
}

void FImageCommentPluginModule::CreateImageComment_K2()
{
	// 1. 获取活动标签页
	TSharedPtr<SDockTab> ActiveTab = FGlobalTabmanager::Get()->GetActiveTab();
	if (!ActiveTab.IsValid()) return;
	
	// 2. 安全转换为图表编辑器
	TSharedPtr<SGraphEditor> GraphEditor = StaticCastSharedRef<SGraphEditor>(ActiveTab->GetContent());
	if (!GraphEditor.IsValid()) return;
	
	// 3.
	UEdGraph* CurrentGraph = GraphEditor->GetCurrentGraph();
	if (!IsValid(CurrentGraph)) return;

	//Debug::Print(CurrentGraph->GetName());
	
	//if (const UEdGraphSchema* Schema = CurrentGraph->GetSchema())
	{
		//if (Schema->IsA(UEdGraphSchema_K2::StaticClass())) //检查是蓝图才创建. 暂时不检查
		{
			FEdGraphSchemaAction_AddImageComment_K2 CommentAction;
			CommentAction.PerformAction(CurrentGraph, nullptr, GraphEditor->GetPasteLocation());
		}
	}
}

void FImageCommentPluginModule::BindAddImageCommentAction_Material()
{
	IMaterialEditorModule& MaterialEditorModule = FModuleManager::LoadModuleChecked<IMaterialEditorModule>("MaterialEditor");
	
	MaterialEditorModule.OnMaterialEditorOpened().AddStatic(&FImageCommentPluginModule::BindMaterialEditorAction);
	
	MaterialEditorModule.OnMaterialFunctionEditorOpened().AddStatic(&FImageCommentPluginModule::BindMaterialEditorAction);
}

void FImageCommentPluginModule::BindMaterialEditorAction(TWeakPtr<IMaterialEditor> MaterialEditor)
{
	//绑定快捷键创建节点
	TSharedRef<FUICommandList> SharedCommands = MaterialEditor.Pin()->GetToolkitCommands();

	//绑定按键创建节点事件
	SharedCommands->MapAction(
		ImageCommentActions::Get().CreateImageComment,
		FExecuteAction::CreateStatic(&FImageCommentPluginModule::CreateImageComment_Material)
	);
	
	RebuildMaterialImageCommentsOnOpened(MaterialEditor);
}

void FImageCommentPluginModule::CreateImageComment_Material()
{
	TSharedPtr<SDockTab> ActiveTab = FGlobalTabmanager::Get()->GetActiveTab();
	if (!ActiveTab.IsValid()) return;
			
	// 2. 安全转换为图表编辑器
	TSharedPtr<SGraphEditor> GraphEditor = StaticCastSharedRef<SGraphEditor>(ActiveTab->GetContent());
	if (!GraphEditor.IsValid()) return;
			
	// 3.
	UEdGraph* CurrentGraph = GraphEditor->GetCurrentGraph();
	if (!IsValid(CurrentGraph)) return;

	//面板和蓝图的类一样,就是采用统一的创建节点方式不行,看看哪里不一样. 是不是节点不能放到材质图表???
	FMaterialGraphSchemaAction_AddImageComment CommentAction;
	CommentAction.PerformAction(CurrentGraph, nullptr, GraphEditor->GetPasteLocation());
}

void FImageCommentPluginModule::RebuildMaterialImageCommentsOnOpened(TWeakPtr<IMaterialEditor> MaterialEditor)
{
	UMaterialInterface* MaterialInterface = MaterialEditor.Pin()->GetMaterialInterface();
	if (!MaterialInterface) return;
	
	UMaterial* Material = Cast<UMaterial>(MaterialInterface);
	if (!Material) return;

	
	auto RebuildImageCommentNodes = [Material]()
	{
		TConstArrayView<TObjectPtr<UMaterialExpressionComment>> MaterialExpressionComments = IsValid(Material->MaterialGraph->MaterialFunction) ?
			Material->MaterialGraph->MaterialFunction->GetEditorComments() : Material->GetEditorComments();
	
		
		for(TObjectPtr<UMaterialExpressionComment> MaterialExpressionComment : MaterialExpressionComments)
		{
			FString ImagePath = ImageCommentUtilities::DecodeImagePathFromComment(MaterialExpressionComment);
			if(ImagePath.IsEmpty()) continue; //无图像路径,保留原生节点
			//图像路径下无文件(可能被删除),保留原生节点,并清除路径
			if(!ImageCommentUtilities::DoesImageExistInPath(ImagePath))
			{
				ImageCommentUtilities::RemoveExistingImageEncoding(MaterialExpressionComment);
				continue;
			}
			//Debug::Print(MaterialExpressionComment.Get()->Text);
			FMaterialGraphSchemaAction_LoadImageComment CommentAction(MaterialExpressionComment,ImagePath);
			CommentAction.PerformAction(Material->MaterialGraph, nullptr, FVector2D());
		}
	};
	
	double StartTime = FPlatformTime::Seconds();
	
	FTSTicker::GetCoreTicker().AddTicker(FTickerDelegate::CreateLambda([Material,StartTime,RebuildImageCommentNodes](float DeltaTime) -> bool
	{
		double ElapsedTime = FPlatformTime::Seconds() - StartTime;
		
		if (ElapsedTime > 5.0) return false;//5秒后结束尝试

		//这里获取不到, 可能还未被设置进来
		if(Material->MaterialGraph)
		{
			RebuildImageCommentNodes();
			return false;
		}
		//true继续, false结束
		return true;
	}), 0.01f/*每0.01秒尝试一次*/);
}

void FImageCommentPluginModule::BindAddImageCommentAction_NiagaraSystem()
{
	GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->OnAssetEditorOpened().AddLambda([](UObject* Object)
	{
		if (Object)
		{
			if(UNiagaraSystem* NiagaraSystem = Cast<UNiagaraSystem>(Object))
			{
				FNiagaraEditorModule& NiagaraEditorModule = FModuleManager::LoadModuleChecked<FNiagaraEditorModule>("NiagaraEditor");
				if(TSharedPtr<FNiagaraSystemViewModel> NiagaraSystemViewModel = NiagaraEditorModule.GetExistingViewModelForSystem(NiagaraSystem))
				{
					if(TSharedPtr<FNiagaraOverviewGraphViewModel> NiagaraOverviewGraphViewModel = NiagaraSystemViewModel->GetOverviewGraphViewModel())
					{
						NiagaraOverviewGraphViewModel->GetCommands()->MapAction(
						ImageCommentActions::Get().CreateImageComment,
						FExecuteAction::CreateLambda([NiagaraOverviewGraphViewModel]()
						{
							//获取不到正确的GraphEditor,有效,但一旦调用就引发崩溃, 不使用创建节点只能在0位置,尺寸由节点重设可以忽略
							/*TSharedPtr<SDockTab> ActiveTab = FGlobalTabmanager::Get()->GetActiveTab();
							if (!ActiveTab.IsValid()) return;
							TSharedPtr<SGraphEditor> GraphEditor = StaticCastSharedRef<SGraphEditor>(ActiveTab->GetContent());
							if (!GraphEditor.IsValid()) return;*/
							
							FNiagaraSchemaAction_NewImageComment CommentAction/*(GraphEditor)*/;
							CommentAction.PerformAction(NiagaraOverviewGraphViewModel->GetGraph(), nullptr, FVector2D());
						})
						);
					}
				}
			}
		}
	});
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FImageCommentPluginModule, ImageCommentPlugin)






















