﻿// Copyright lurongjiu 2025. All Rights Reserved.

#include "SGraphNode_ImageComment.h"

#include "DebugHelper_ImageComment.h"
#include "EdGraphNode_ImageComment.h"


void SGraphNode_ImageComment::Construct(const FArguments& InArgs, UEdGraphNode_ImageComment* InNode)
{
	ImageCommentNode = InNode;
	SGraphNodeComment::Construct(SGraphNodeComment::FArguments(), InNode);
}

int32 SGraphNode_ImageComment::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry,const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId,const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	if(!ImageCommentNode->DrawPureImage)
	{
		/*LayerId = */SGraphNodeComment::OnPaint(Args, AllottedGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle,bParentEnabled);
	}
	
	const FSlateBrush* ImageBrush = GetBackgroundBrush();
	const FPaintGeometry PaintGeometry = CalculatePaintGeometry(AllottedGeometry,ImageBrush->GetImageSize());
	
	// 绘制图像背景
	FSlateDrawElement::MakeBox(
		OutDrawElements,
		LayerId,
		PaintGeometry,
		ImageBrush,
		ESlateDrawEffect::None,
		FLinearColor(1.0f, 1.0f, 1.0f, ImageCommentNode->ImageOpacity)
	);
	LayerId++;  // 直接递增
	
	return LayerId;
}

/*
float SGraphNode_ImageComment::GetTitleHeight() const
{
	return this->GetTitleBarHeight();
}*/

const FSlateBrush* SGraphNode_ImageComment::GetBackgroundBrush() const
{
	// 步骤1：确保画刷对象存在
	if (!CachedBackgroundBrush.IsValid())
	{
		CachedBackgroundBrush = MakeShareable(new FSlateBrush());
		// 设置默认配置
		CachedBackgroundBrush->DrawAs = ESlateBrushDrawType::Image;
		CachedBackgroundBrush->Tiling = ESlateBrushTileType::NoTile;
		CachedBackgroundBrush->Margin = FMargin(0);
	}

	if(ImageCommentNode)
	{
		//else if(ImageCommentNode->ImageSource == EImageCommentSource::Computer)
		if(ImageCommentNode->BackgroundImagePath.IsEmpty())
		{
			CachedBackgroundBrush->DrawAs = ESlateBrushDrawType::NoDrawType;
			return CachedBackgroundBrush.Get();
		}
		
		static TMap<FString, TSharedPtr<FSlateDynamicImageBrush>> BrushCache;
		if (TSharedPtr<FSlateDynamicImageBrush>* CachedBrush = BrushCache.Find(ImageCommentNode->BackgroundImagePath))
		{
			if(CachedBrush->Get()->GetImageSize() != ImageCommentNode->CachedImageSize)
			{
				CachedBrush->Get()->SetImageSize(ImageCommentNode->CachedImageSize);
			}
			return CachedBrush->Get();
		}
		TSharedPtr<FSlateDynamicImageBrush> NewBrush = MakeShareable(new FSlateDynamicImageBrush(FName(*ImageCommentNode->BackgroundImagePath),ImageCommentNode->CachedImageSize));
		if (NewBrush.IsValid())
		{
			BrushCache.Add(ImageCommentNode->BackgroundImagePath, NewBrush);
			return NewBrush.Get();
		}
	}
	
	return CachedBackgroundBrush.Get();
}

FPaintGeometry SGraphNode_ImageComment::CalculatePaintGeometry(const FGeometry& AllottedGeometry,const FVector2D& ImageSize) const
{
	FMargin LocalPadding = ImageCommentNode ? ImageCommentNode->Padding : FMargin(10.f, 10.f, 10.f, 10.f);
	LocalPadding.Top += GetTitleBarHeight();

	//计算位置偏移
	FVector2D Offset = FVector2D(LocalPadding.GetTopLeft());

	//计算应设尺寸
	//计算拉伸尺寸
	FVector2D Size = AllottedGeometry.GetLocalSize() - FVector2D(LocalPadding.GetDesiredSize());
	// 确保大小有效
	Size.X = FMath::Max(Size.X, 1.0f);
	Size.Y = FMath::Max(Size.Y, 1.0f);
	//计算保持比例尺寸
	float Scale = FMath::Min(Size.X / ImageSize.X,Size.Y / ImageSize.Y);
	//Size *= Scale;
	
	return AllottedGeometry.MakeChild(
		ImageSize*Scale,
		FSlateLayoutTransform(Offset)
	).ToPaintGeometry();
}
