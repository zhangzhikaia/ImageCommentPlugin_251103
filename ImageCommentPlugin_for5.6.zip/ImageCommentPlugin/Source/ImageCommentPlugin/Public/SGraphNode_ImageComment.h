﻿// Copyright lurongjiu 2025. All Rights Reserved.

#pragma once
#include "SGraphNodeComment.h"

class UEdGraphNode_ImageComment;

class SGraphNode_ImageComment : public SGraphNodeComment
{
public:
	SLATE_BEGIN_ARGS(SGraphNode_ImageComment){}
		
	SLATE_END_ARGS()

	void Construct( const FArguments& InArgs, UEdGraphNode_ImageComment* InNode );
	
	virtual int32 OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const override;


private:
	//
	UEdGraphNode_ImageComment* ImageCommentNode;

	// 缓存画刷避免每帧创建
	mutable TSharedPtr<FSlateBrush> CachedBackgroundBrush;
    
	// 获取背景画刷的函数
	const FSlateBrush* GetBackgroundBrush() const;

	//计算图像边界
	FPaintGeometry CalculatePaintGeometry(const FGeometry& AllottedGeometry,const FVector2D& ImageSize) const;
};
