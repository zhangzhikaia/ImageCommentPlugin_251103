// Copyright lurongjiu 2025. All Rights Reserved.

using UnrealBuildTool;

public class ImageCommentPlugin : ModuleRules
{
	public ImageCommentPlugin(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
		
		PublicIncludePaths.AddRange(
			new string[] {
				// ... add public include paths required here ...
			}
			);
				
		
		PrivateIncludePaths.AddRange(
			new string[] {
				// ... add other private include paths required here ...
			}
			);
			
		
		PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				// ... add other public dependencies that you statically link with here ...
				"UnrealEd", //Ed节点对象
				"GraphEditor",//SGraph节点widget
				"InputCore",//快捷键输入
				"BlueprintGraph", //UEdGraphSchema_K2
				"MaterialEditor", //材质面板编辑
				"ToolMenus", //材质面板节点上下文构造
				"NiagaraEditor", //
				"Niagara",
				"Sequencer", //NiagaraSystemViewModel依赖
				
			}
			);
			
		
		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"CoreUObject",
				"Engine",
				"Slate",
				"SlateCore", 
				// ... add private dependencies that you statically link with here ...	
			}
			);
		
		/*if (Target.Type == TargetRules.TargetType.Editor)
		{
			PublicDependencyModuleNames.AddRange(
				new string[]
				{
					"UnrealEd",//Ed节点对象
					//"AssetTools",
					"ToolMenus", //材质面板节点上下文构造
					//new
					//"DesktopPlatform",
				}
			);
			PrivateDependencyModuleNames.AddRange(
				new string[]
				{
					//"AssetTools",
				}
			);
		}*/
		
		DynamicallyLoadedModuleNames.AddRange(
			new string[]
			{
				// ... add any modules that your module loads dynamically here ...
			}
			);
	}
}
