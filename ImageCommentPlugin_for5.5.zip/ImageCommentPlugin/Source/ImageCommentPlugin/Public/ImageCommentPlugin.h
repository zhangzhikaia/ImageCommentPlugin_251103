// Copyright lurongjiu 2025. All Rights Reserved.

#pragma once

#include "Modules/ModuleManager.h"
#include "ViewModels/NiagaraOverviewGraphViewModel.h"

class IMaterialEditor;

class FImageCommentPluginModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

private:
	
	//K2
	static void BindAddImageCommentAction_K2();
	static void CreateImageComment_K2();

	//Material
	static void BindAddImageCommentAction_Material();
	static void BindMaterialEditorAction(TWeakPtr<IMaterialEditor> MaterialEditor);
	static void CreateImageComment_Material();
	static void RebuildMaterialImageCommentsOnOpened(TWeakPtr<IMaterialEditor> MaterialEditor);

	//NiagaraSystem
	static void BindAddImageCommentAction_NiagaraSystem();
	
};
