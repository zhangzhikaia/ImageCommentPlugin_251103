// Copyright lurongjiu 2025. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "EdGraphNode_Comment.h"
#include "EdGraphNode_ImageComment.generated.h"

/**
 * 
 */
/*UENUM()
enum class EImageCommentSource : uint8
{
	None UMETA(DisplayName="None"), 
	Project UMETA(DisplayName="ProjectTexture"), 
	Computer UMETA(DisplayName="ComputerImage")
};*/

UENUM()
enum class ImageCommentNodeType : uint8
{
	K2, 
	Material
};

class SGraphNode_ImageComment;

UCLASS()
class IMAGECOMMENTPLUGIN_API UEdGraphNode_ImageComment : public UEdGraphNode_Comment
{
	GENERATED_BODY()

	//UEdGraphNode_ImageComment(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

public:
	
	// 
	UFUNCTION(CallInEditor, Category = "Image Comment")
	void ReplaceImageFromClipboard();
	UFUNCTION(CallInEditor, Category = "Image Comment")
	void ClearImage();
	//图像透明度
	UPROPERTY(EditAnywhere, Category = "Image Comment")
	float ImageOpacity = 1.0f;
	//图像距离边界
	UPROPERTY(EditAnywhere, Category = "Image Comment")
	FMargin Padding = FMargin(10.f, 10.f, 10.f, 10.f);
	UPROPERTY(EditAnywhere, Category = "Image Comment")
	bool DrawPureImage = false;
	
	//外部图像路径
	UPROPERTY()
	FString BackgroundImagePath;
	//缓存图像尺寸,它不会随节点size变化而变化,但可能会缩放
	UPROPERTY()
	FVector2D CachedImageSize;
	//蓝图还是材质
	UPROPERTY()
	ImageCommentNodeType NodeType;
	/** Material Comment that this node represents 对于材质使用的,所有变量的修改要带上MaterialExpressionComment的同步*/
	//UPROPERTY()
	TObjectPtr<class UMaterialExpressionComment> MaterialExpressionComment;

	//新建还是读取
	bool bIsNewMaterialNode;
public:
	//~ Begin UEdGraphNode Interface
	virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const override;
	//节点创建时调用
	virtual void PostPlacedNewNode() override;
	//打开面板时调用(当构造用)
	virtual void PostLoad() override;

	virtual void OnRenameNode(const FString& NewName) override;

#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION <= 5
	virtual void ResizeNode(const FVector2D& NewSize) override;
#else
	virtual void ResizeNode(const FVector2f& NewSize) override;
#endif
	
	//材质面板的上下文菜单构造
	virtual void GetNodeContextMenuActions(class UToolMenu* Menu, class UGraphNodeContextMenuContext* Context) const override;
	//~ End UEdGraphNode Interface

	
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	
	//无效
	void PostCopyNode();
	//无效
	virtual void PostDuplicate(bool bDuplicateForPIE) override;

	//在复制(剪切)时会被触发
	virtual void PrepareForCopying() override;

	//在粘贴时会被触发
	virtual void PostEditImport() override;

	//无知
	virtual bool CanCreateUnderSpecifiedSchema(const UEdGraphSchema* Schema) const override;
	
	//delete时并不调用
	virtual void BeginDestroy() override;

private:
	/*Create SGraphNode_ImageComment*/
	virtual TSharedPtr<SGraphNode> CreateVisualWidget() override;

	//无效
	//virtual TSharedPtr<SWidget> CreateNodeImage() const override;

public:
	void UpdateImageSize();

	void ResetMaterialExpressionOwner();

	//test

	/*mutable TSharedPtr<FSlateBrush> CachedBackgroundBrush;
	const FSlateBrush* GetBackgroundBrush() const;*/

};
