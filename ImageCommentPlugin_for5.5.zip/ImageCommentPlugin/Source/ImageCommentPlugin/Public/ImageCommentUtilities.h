﻿// Copyright lurongjiu 2025. All Rights Reserved.

#pragma once

class ImageCommentUtilities
{
public:
	static FVector2D ReadImageSize(const FString& Path);

	static bool OpenSelectImageDialog(FString& Path);
	
	static bool HasImageInClipboard();

	static FString GetProjectSavedDir();

	static FString GenerateUniqueImageName();

	static FString SaveClipboardImageToProject();

	static bool SaveClipboardImageToFile_Windows(const FString& FilePath);

	static bool DoesImageExistInPath(const FString& FilePath);

	static void EncodeImageDataToComment(UMaterialExpressionComment* Comment, const FString& ImagePath);

	static FString DecodeImagePathFromComment(const UMaterialExpressionComment* Comment);

	static void RemoveExistingImageEncoding(UMaterialExpressionComment* Comment);

	static FString GetCommentUserText(const UMaterialExpressionComment* Comment);

	static void SetCommentUserText(UMaterialExpressionComment* Comment, const FString& NewUserText);
};
