﻿// Copyright lurongjiu 2025. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "DebugHelper_ImageComment.h"
#include "EdGraph/EdGraphSchema.h"

#include "FEdGraphSchemaAction_AddImageComment.generated.h"

USTRUCT()
struct FEdGraphSchemaAction_AddImageComment_K2 : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

	// Simple type info
	static FName StaticGetTypeId() {static FName Type("FEdGraphSchemaAction_AddImageComment"); return Type;}
	virtual FName GetTypeId() const override { return StaticGetTypeId(); }

	FEdGraphSchemaAction_AddImageComment_K2()
	: FEdGraphSchemaAction(FText(), NSLOCTEXT("ImageComment", "AddImageComment", "Add Image Comment..."), NSLOCTEXT("ImageComment", "AddImageComment_Tooltip", "Create a resizable image comment box."), 0)
	{
	}

	FEdGraphSchemaAction_AddImageComment_K2(FText InDescription, FText InToolTip)
		: FEdGraphSchemaAction(FText(), MoveTemp(InDescription), MoveTemp(InToolTip), 0)
	{
	}
	
	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	// End of FEdGraphSchemaAction interface
};

USTRUCT()
struct FMaterialGraphSchemaAction_AddImageComment : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

	// Simple type info
	static FName StaticGetTypeId() {static FName Type("FMaterialGraphSchemaAction_AddImageComment"); return Type;}
	virtual FName GetTypeId() const override { return StaticGetTypeId(); }

	FMaterialGraphSchemaAction_AddImageComment() 
		: FEdGraphSchemaAction()
	{}

	FMaterialGraphSchemaAction_AddImageComment(FText InNodeCategory, FText InMenuDesc, FText InToolTip, const int32 InGrouping)
		: FEdGraphSchemaAction(MoveTemp(InNodeCategory), MoveTemp(InMenuDesc), MoveTemp(InToolTip), InGrouping)
	{}
	
	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	// End of FEdGraphSchemaAction interface
};

USTRUCT()
struct FMaterialGraphSchemaAction_LoadImageComment : public FEdGraphSchemaAction
{
	GENERATED_USTRUCT_BODY()

	// Simple type info
	static FName StaticGetTypeId() {static FName Type("FMaterialGraphSchemaAction_LoadImageComment"); return Type;}
	virtual FName GetTypeId() const override { return StaticGetTypeId(); }

	FMaterialGraphSchemaAction_LoadImageComment() 
		: FEdGraphSchemaAction()
	{}

	FMaterialGraphSchemaAction_LoadImageComment(TWeakObjectPtr<UMaterialExpressionComment> InComment,const FString& ImagePath) 
		: FEdGraphSchemaAction() ,
	MaterialExpressionComment(InComment),
	CacheImagePath(ImagePath)
	{}

	FMaterialGraphSchemaAction_LoadImageComment(FText InNodeCategory, FText InMenuDesc, FText InToolTip, const int32 InGrouping)
		: FEdGraphSchemaAction(MoveTemp(InNodeCategory), MoveTemp(InMenuDesc), MoveTemp(InToolTip), InGrouping)
	{}
	
	// FEdGraphSchemaAction interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	// End of FEdGraphSchemaAction interface

	TWeakObjectPtr<UMaterialExpressionComment> MaterialExpressionComment;
	FString CacheImagePath;
};

USTRUCT()
struct FNiagaraSchemaAction_NewImageComment : public FEdGraphSchemaAction
{
public:
	GENERATED_USTRUCT_BODY();

	// Simple type info
	static FName StaticGetTypeId() {static FName Type("FNiagaraSchemaAction_NewImageComment"); return Type;}
	virtual FName GetTypeId() const override { return StaticGetTypeId(); }

	FNiagaraSchemaAction_NewImageComment()
		: FEdGraphSchemaAction()
		, GraphEditor(nullptr)
	{}

	FNiagaraSchemaAction_NewImageComment(const TSharedPtr<SGraphEditor>& InGraphEditor)
		: FEdGraphSchemaAction()
		, GraphEditor(InGraphEditor)
	{}

	//~ Begin FEdGraphSchemaAction Interface
	virtual UEdGraphNode* PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode = true) override;
	//~ End FEdGraphSchemaAction Interface

private:
	/** SGraphEditor to use for getting new comment boxes dimensions */
	TSharedPtr<SGraphEditor> GraphEditor;
};

