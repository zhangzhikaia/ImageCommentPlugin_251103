﻿// Copyright lurongjiu 2025. All Rights Reserved.

#pragma once
//
#if 0
#include "Kismet/KismetStringLibrary.h"
#define DoubleToString UKismetStringLibrary::Conv_DoubleToString

namespace Debug
{
	static void Print(const FString& message, FColor color = FColor::Blue)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s"), *message);
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message);
		}
	}

	static void Print(int message, FColor color = FColor::Blue)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s"), *FString::FromInt(message));
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, FString::FromInt(message));
		}
	}

	static void Print(const bool state, FColor color = FColor::Blue)
	{
		if(state)
		{
			UE_LOG(LogTemp, Warning, TEXT("True"));
			if (GEngine)
			{
				GEngine->AddOnScreenDebugMessage(-1, 3, color, TEXT("True"));
			}
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("False"));
			if (GEngine)
			{
				GEngine->AddOnScreenDebugMessage(-1, 3, color, TEXT("False"));
			}
		}
	}

	static void Print(const FName& message, FColor color = FColor::Blue)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s"), *message.ToString());
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message.ToString());
		}
	}

	static void Print(const float& message, FColor color = FColor::Blue)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s"), *DoubleToString(message));
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, DoubleToString(message));
		}
	}
}
#undef DoubleToString

#endif