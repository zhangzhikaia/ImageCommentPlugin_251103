﻿// Copyright lurongjiu 2025. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Framework/Commands/Commands.h"

class ImageCommentActions : public TCommands<ImageCommentActions>
{
public:
	ImageCommentActions()
		: TCommands<ImageCommentActions>( TEXT("GraphEditorImageComment"), NSLOCTEXT("ImageCommentContexts", "GraphEditorImageComment", "Graph Editor Image Comment"), NAME_None, FAppStyle::GetAppStyleSetName() )
	{
	}
	
	virtual ~ImageCommentActions()
	{
	}

	virtual void RegisterCommands() override;

	TSharedPtr<FUICommandInfo> CreateImageComment;
};
