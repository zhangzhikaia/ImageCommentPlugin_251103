﻿// Copyright lurongjiu 2025. All Rights Reserved.

#include "ImageCommentUtilities.h"

//
#include "DesktopPlatformModule.h"
#include "IDesktopPlatform.h"
#include "EditorDirectories.h"
//
#include "IImageWrapper.h"
#include "IImageWrapperModule.h"
#include "Materials/MaterialExpressionComment.h"

//#include "HAL/PlatformApplicationMisc.h"
#if PLATFORM_WINDOWS
#include "Windows/AllowWindowsPlatformTypes.h"
#include <windows.h>
#include "Windows/HideWindowsPlatformTypes.h"
#endif


FVector2D ImageCommentUtilities::ReadImageSize(const FString& Path)
{
	FVector2D Size = FVector2D::ZeroVector;
	
	TArray<uint8> FileData;
	if(FFileHelper::LoadFileToArray(FileData, *Path))
	{
		IImageWrapperModule& ImageWrapperModule = FModuleManager::LoadModuleChecked<IImageWrapperModule>(FName("ImageWrapper"));
	
		EImageFormat ImageFormat = ImageWrapperModule.DetectImageFormat(FileData.GetData(), FileData.Num());
		if (ImageFormat != EImageFormat::Invalid)
		{
			TSharedPtr<IImageWrapper> ImageWrapper = ImageWrapperModule.CreateImageWrapper(ImageFormat);
			if (ImageWrapper.IsValid() && ImageWrapper->SetCompressed(FileData.GetData(), FileData.Num()))
			{
				Size = FVector2D(ImageWrapper->GetWidth(), ImageWrapper->GetHeight());
			}
		}
	}
	return Size;
}

bool ImageCommentUtilities::OpenSelectImageDialog(FString& Path)
{
	IDesktopPlatform* DesktopPlatform = FDesktopPlatformModule::Get();
	if (ensure(DesktopPlatform))
	{
		TArray<FString> FilePath;
		
		const bool Success = DesktopPlatform->OpenFileDialog(
			FSlateApplication::Get().FindBestParentWindowHandleForDialogs(nullptr),
			NSLOCTEXT("ImageComment","ImageCommentDialogTitle", "SelectImage...").ToString(),
			FEditorDirectories::Get().GetLastDirectory(ELastDirectory::GENERIC_EXPORT),
			TEXT(""),
			TEXT("Image files (*.png;*.jpg;*.jpeg;*.bmp)|*.png;*.jpg;*.jpeg;*.bmp|All files (*.*)|*.*"),
			EFileDialogFlags::None,
			FilePath
			);
		if (Success)
		{
			Path = FilePath[0];
			return true;
		}
	}
	return false;
}

bool ImageCommentUtilities::HasImageInClipboard()
{
#if PLATFORM_WINDOWS
	return ::IsClipboardFormatAvailable(CF_BITMAP) != Windows::FALSE;
#else
	// 其他平台暂时不支持剪贴板图像检测
	return false;
#endif
}

FString ImageCommentUtilities::GetProjectSavedDir()
{
	return FPaths::ProjectSavedDir() / TEXT("ImageComments");
}

FString ImageCommentUtilities::GenerateUniqueImageName()
{
	FString Timestamp = FDateTime::Now().ToString(TEXT("%Y%m%d_%H%M%S_%s"));
	return FString::Printf(TEXT("ClipboardImage_%s.png"), *Timestamp);
}

FString ImageCommentUtilities::SaveClipboardImageToProject()
{
	FString SaveDir = GetProjectSavedDir();
	if (!FPaths::DirectoryExists(SaveDir))
	{
		IFileManager::Get().MakeDirectory(*SaveDir, true);
	}
	// 生成唯一文件名
	FString FileName = GenerateUniqueImageName();
	FString FullPath = SaveDir / FileName;
	
	if(SaveClipboardImageToFile_Windows(FullPath))
	{
		return FullPath;
	}
	
	return FString();
	
}

bool ImageCommentUtilities::SaveClipboardImageToFile_Windows(const FString& FilePath)
{
	if (!::OpenClipboard(nullptr))
	{
		//UE_LOG(LogTemp, Error, TEXT("无法打开剪贴板"));
		return false;
	}

	bool bSuccess = false;
	HBITMAP hBitmap = static_cast<HBITMAP>(::GetClipboardData(CF_BITMAP));
    
	if (!hBitmap)
	{
		//UE_LOG(LogTemp, Error, TEXT("剪贴板中没有位图数据"));
		::CloseClipboard();
		return false;
	}

	// 获取位图信息
	BITMAP bitmap;
	if (!::GetObjectW(hBitmap, sizeof(BITMAP), &bitmap))
	{
		//UE_LOG(LogTemp, Error, TEXT("无法获取位图信息"));
		::CloseClipboard();
		return false;
	}

	//UE_LOG(LogTemp, Warning, TEXT("获取到位图: %dx%d, 位深度: %d"), bitmap.bmWidth, bitmap.bmHeight, bitmap.bmBitsPixel);

	// 创建设备上下文
	HDC hDC = ::GetDC(nullptr);
	HDC hMemDC = ::CreateCompatibleDC(hDC);
    
	// 选择位图到内存DC
	HBITMAP hOldBitmap = static_cast<HBITMAP>(::SelectObject(hMemDC, hBitmap));

	// 准备位图信息头
	BITMAPINFOHEADER bi;
	bi.biSize = sizeof(BITMAPINFOHEADER);
	bi.biWidth = bitmap.bmWidth;
	bi.biHeight = -bitmap.bmHeight;  // 负值表示从上到下的位图
	bi.biPlanes = 1;
	bi.biBitCount = 32;
	bi.biCompression = BI_RGB;
	bi.biSizeImage = 0;
	bi.biXPelsPerMeter = 0;
	bi.biYPelsPerMeter = 0;
	bi.biClrUsed = 0;
	bi.biClrImportant = 0;

	// 分配内存存储位图数据
	DWORD dwBmpSize = ((bitmap.bmWidth * bi.biBitCount + 31) / 32) * 4 * bitmap.bmHeight;
	TArray<uint8> BitmapData;
	BitmapData.SetNum(dwBmpSize);

	// 获取位图数据
	if (::GetDIBits(hDC, hBitmap, 0, bitmap.bmHeight, BitmapData.GetData(), (BITMAPINFO*)&bi, DIB_RGB_COLORS))
	{
		// 使用 ImageWrapper 转换为 PNG
		IImageWrapperModule& ImageWrapperModule = FModuleManager::LoadModuleChecked<IImageWrapperModule>(FName("ImageWrapper"));
		TSharedPtr<IImageWrapper> ImageWrapper = ImageWrapperModule.CreateImageWrapper(EImageFormat::PNG);
        
		if (ImageWrapper.IsValid())
		{
			// 设置原始图像数据
			if (ImageWrapper->SetRaw(BitmapData.GetData(), BitmapData.Num(), bitmap.bmWidth, bitmap.bmHeight, ERGBFormat::BGRA, 8))
			{
				// 获取压缩后的 PNG 数据
				const TArray64<uint8>& CompressedData = ImageWrapper->GetCompressed();
				if (CompressedData.Num() > 0)
				{
					// 保存到文件
					if (FFileHelper::SaveArrayToFile(CompressedData, *FilePath))
					{
						bSuccess = true;
						//UE_LOG(LogTemp, Warning, TEXT("成功保存 PNG 图像: %s"), *FilePath);
					}
				}
			}
		}
	}


	// 清理资源
	::SelectObject(hMemDC, hOldBitmap);
	::DeleteDC(hMemDC);
	::ReleaseDC(nullptr, hDC);
	::CloseClipboard();

	return bSuccess;
}

bool ImageCommentUtilities::DoesImageExistInPath(const FString& FilePath)
{
	return FPaths::FileExists(FilePath);
}

void ImageCommentUtilities::EncodeImageDataToComment(UMaterialExpressionComment* Comment, const FString& ImagePath)
{
	if (!Comment) return;
    
	FString OriginalText = Comment->Text;
    
	// 移除可能存在的旧编码
	RemoveExistingImageEncoding(Comment);
    
	// 添加编码前缀
	FString EncodedData = FString::Printf(TEXT("[IMG:%s]"), *ImagePath);
	Comment->Text = EncodedData + OriginalText;
	Comment->Modify();
}

FString ImageCommentUtilities::DecodeImagePathFromComment(const UMaterialExpressionComment* Comment)
{
	if (!Comment) return FString();
    
	FString CommentText = Comment->Text;
    
	// 查找编码标记
	if (CommentText.StartsWith(TEXT("[IMG:")))
	{
		int32 EndBracket = CommentText.Find(TEXT("]"));
		if (EndBracket != INDEX_NONE)
		{
			return CommentText.Mid(5, EndBracket - 5); // "[IMG:".Len() = 5
		}
	}
    
	return FString();
}

void ImageCommentUtilities::RemoveExistingImageEncoding(UMaterialExpressionComment* Comment)
{
	if (!Comment) return;
    
	FString CommentText = Comment->Text;
    
	if (CommentText.StartsWith(TEXT("[IMG:")))
	{
		int32 EndBracket = CommentText.Find(TEXT("]"));
		if (EndBracket != INDEX_NONE)
		{
			Comment->Text = CommentText.Mid(EndBracket + 1);
		}
	}
}

FString ImageCommentUtilities::GetCommentUserText(const UMaterialExpressionComment* Comment)
{
	if (!Comment) return FString();
    
	FString CommentText = Comment->Text;
    
	// 移除图像编码数据
	if (CommentText.StartsWith(TEXT("[IMG:")))
	{
		int32 EndBracket = CommentText.Find(TEXT("]"));
		if (EndBracket != INDEX_NONE)
		{
			return CommentText.Mid(EndBracket + 1).TrimStart();
		}
	}
	return CommentText;
}

void ImageCommentUtilities::SetCommentUserText(UMaterialExpressionComment* Comment, const FString& NewUserText)
{
	if (!Comment) return;
    
	const FScopedTransaction Transaction(NSLOCTEXT("ImageComment", "SetCommentText", "Set Comment Text"));
	Comment->Modify();
    
	FString CurrentText = Comment->Text;
	FString ImagePath = FString();
	FString OldUserText = FString();
    
	// 分离现有的编码数据和用户文本
	if (CurrentText.StartsWith(TEXT("[IMG:")))
	{
		int32 EndBracket = CurrentText.Find(TEXT("]"));
		if (EndBracket != INDEX_NONE)
		{
			ImagePath = CurrentText.Mid(5, EndBracket - 5);
			OldUserText = CurrentText.Mid(EndBracket + 1).TrimStart();
		}
	}
	else
	{
		OldUserText = CurrentText;
	}
    
	// 重新组合：编码数据 + 新用户文本
	if (!ImagePath.IsEmpty())
	{
		Comment->Text = FString::Printf(TEXT("[IMG:%s]%s"), *ImagePath, *NewUserText);
	}
	else
	{
		Comment->Text = NewUserText;
	}
}











