// Copyright lurongjiu 2025. All Rights Reserved.

#include "EdGraphNode_ImageComment.h"
#include "SGraphNode_ImageComment.h"
#include "DebugHelper_ImageComment.h"
#include "FEdGraphSchemaAction_AddImageComment.h"
#include "GraphEditorActions.h"

#include "ImageCommentUtilities.h"
#include "Framework/Commands/GenericCommands.h"
#include "MaterialGraph/MaterialGraph.h"
#include "MaterialGraph/MaterialGraphSchema.h"
#include "Materials/MaterialExpressionComment.h"

#define LOCTEXT_NAMESPACE "FImageCommentPluginModule"

void UEdGraphNode_ImageComment::ReplaceImageFromClipboard()
{
	if(ImageCommentUtilities::HasImageInClipboard())
	{
		BackgroundImagePath = ImageCommentUtilities::SaveClipboardImageToProject();
		if(!BackgroundImagePath.IsEmpty())
		{
			UpdateImageSize();
			MarkPackageDirty();
		}
	}
}

void UEdGraphNode_ImageComment::ClearImage()
{
	BackgroundImagePath.Empty();
	CachedImageSize = FVector2D::Zero();
	MarkPackageDirty();
}

FText UEdGraphNode_ImageComment::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	if(TitleType == ENodeTitleType::MenuTitle)
	{
		return NSLOCTEXT("ImageComment", "NoImageComment_ListTitle", "Add Image Comment...");
	}
	else if(TitleType == ENodeTitleType::ListView)
	{
		return NSLOCTEXT("ImageComment", "ImageCommentBlock_ListTitle", "Image Comment");	
	}

	return FText::FromString(NodeComment);
}

void UEdGraphNode_ImageComment::PostPlacedNewNode()
{
	//Debug::Print(FString("111111111111111"));
	//新建节点时设置变量. 不使用构造因为构造是打开蓝图就会调用所有节点的构造
	Super::PostPlacedNewNode();

	//是蓝图节点时,新建粘贴图像. 是材质节点时,确定是新节点才粘贴图像. 并初始化变量
	if(NodeType == ImageCommentNodeType::K2 || (NodeType == ImageCommentNodeType::Material && bIsNewMaterialNode))
	{
		if(ImageCommentUtilities::HasImageInClipboard())
		{
			BackgroundImagePath = ImageCommentUtilities::SaveClipboardImageToProject();
			if(!BackgroundImagePath.IsEmpty())
			{
				UpdateImageSize();
				MarkPackageDirty();
				//新建有图像节点时按图像大小设置尺寸, 按标题高度为50加上
				NodeWidth = CachedImageSize.X;
				NodeHeight = CachedImageSize.Y + 50.f;
			}
		}
		//移动模式为不包含内部节点
		MoveMode = ECommentBoxMode::NoGroupMovement;
		//新建节点文字内容
		NodeComment = NSLOCTEXT("ImageComment", "ImageCommentBlock_NewEmptyImageComment", "ImageComment").ToString();
	}
	
	//是材质节点时, 额外为MaterialExpressionComment或从中读取配置变量
	if (NodeType == ImageCommentNodeType::Material && MaterialExpressionComment)
	{
		//无论新节点还是加载节点, 都同一执行的
		//从MaterialExpressionComment读取位置
		NodePosX = MaterialExpressionComment->MaterialExpressionEditorX;
		NodePosY = MaterialExpressionComment->MaterialExpressionEditorY;
		bCommentBubbleVisible_InDetailsPanel = MaterialExpressionComment->bCommentBubbleVisible_InDetailsPanel;
		bCommentBubbleVisible = MaterialExpressionComment->bCommentBubbleVisible_InDetailsPanel;
		bCommentBubblePinned = MaterialExpressionComment->bCommentBubbleVisible_InDetailsPanel;
		this->CommentColor = MaterialExpressionComment->CommentColor;
		this->bColorCommentBubble = MaterialExpressionComment->bColorCommentBubble;
		
		//销毁原comment节点,
		MaterialExpressionComment->GraphNode->DestroyNode();
		//并把新的保存到ExpressionComment(保存进来没有功能必要,仅占位
		MaterialExpressionComment->GraphNode = this;

		//新节点才执行的
		if(bIsNewMaterialNode)
		{
			//把comment和movemode配置到MaterialExpressionComment
			MaterialExpressionComment->bGroupMode = (MoveMode == ECommentBoxMode::GroupMovement);
			MaterialExpressionComment->SizeX = NodeWidth;
			MaterialExpressionComment->SizeY = NodeHeight;
			if(!BackgroundImagePath.IsEmpty())
			{
				ImageCommentUtilities::EncodeImageDataToComment(MaterialExpressionComment,BackgroundImagePath);
			}
			ImageCommentUtilities::SetCommentUserText(MaterialExpressionComment,NodeComment);
		}
		//加载节点执行的
		else
		{
			//从MaterialExpressionComment读取comment和movemode
			MoveMode = MaterialExpressionComment->bGroupMode ? ECommentBoxMode::GroupMovement : ECommentBoxMode::NoGroupMovement;
			NodeWidth = MaterialExpressionComment->SizeX;
			NodeHeight = MaterialExpressionComment->SizeY;
			
			//Debug::Print(MaterialExpressionComment->SizeX);
			//路径在创建时传入,这里解码是重复性能
			//BackgroundImagePath = ImageCommentUtilities::DecodeImagePathFromComment(MaterialExpressionComment);
			NodeComment = ImageCommentUtilities::GetCommentUserText(MaterialExpressionComment);
		}
	}
}

void UEdGraphNode_ImageComment::PostLoad()
{
	Super::PostLoad();
	if(!ImageCommentUtilities::DoesImageExistInPath(BackgroundImagePath))
	{
		BackgroundImagePath.Empty();
		CachedImageSize = FVector2D::Zero();
	}
}

void UEdGraphNode_ImageComment::OnRenameNode(const FString& NewName)
{
	Super::OnRenameNode(NewName);
	//材质中重命名设置到MaterialExpressionComment
	if (NodeType == ImageCommentNodeType::Material && MaterialExpressionComment)
	{
		// send property changed events
		FProperty* NodeCommentProperty = FindFProperty<FProperty>(GetClass(), "NodeComment");
		if(NodeCommentProperty != NULL)
		{
			PreEditChange(NodeCommentProperty);
			
			NodeComment = NewName;
			
			FPropertyChangedEvent NodeCommentPropertyChangedEvent(NodeCommentProperty);
			PostEditChangeProperty(NodeCommentPropertyChangedEvent);
		}
	}
}

#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION <= 5
void UEdGraphNode_ImageComment::ResizeNode(const FVector2D& NewSize)
#else
void UEdGraphNode_ImageComment::ResizeNode(const FVector2f& NewSize)
#endif
{
	Super::ResizeNode(NewSize);
	
	//材质中Resize设置到MaterialExpressionComment
	if (NodeType == ImageCommentNodeType::Material && MaterialExpressionComment)
	{
		MaterialExpressionComment->SizeX = NodeWidth;
		MaterialExpressionComment->SizeY = NodeHeight;
		MaterialExpressionComment->MaterialExpressionEditorX = NodePosX;
		MaterialExpressionComment->MaterialExpressionEditorY = NodePosY;
		MaterialExpressionComment->MarkPackageDirty();
		//MaterialExpressionComment->Modify();
	}
}

void UEdGraphNode_ImageComment::GetNodeContextMenuActions(class UToolMenu* Menu,class UGraphNodeContextMenuContext* Context) const
{
	Super::GetNodeContextMenuActions(Menu, Context);
	if(NodeType == ImageCommentNodeType::K2) return;
	
	if (Context->Node && !Context->Pin)
	{
		// frequently used common options
		{
			FToolMenuSection& Section = Menu->AddSection("MaterialEditorCommentMenu");
			Section.AddMenuEntry(FGenericCommands::Get().Delete);
			Section.AddMenuEntry(FGenericCommands::Get().Cut);
			Section.AddMenuEntry(FGenericCommands::Get().Copy);
			Section.AddMenuEntry(FGenericCommands::Get().Duplicate);
		}
		
		{
			FToolMenuSection& Section = Menu->AddSection("EdGraphSchemaOrganization", LOCTEXT("OrganizationHeader", "Organization"));
			Section.AddMenuEntry(FGraphEditorCommands::Get().CollapseNodes);
			Section.AddMenuEntry(FGraphEditorCommands::Get().ExpandNodes);

			Section.AddSubMenu(
				"Alignment",
				LOCTEXT("AlignmentHeader", "Alignment"),
				FText(),
				FNewToolMenuDelegate::CreateLambda([](UToolMenu* InMenu)
				{
					{
						FToolMenuSection& SubMenuSection = InMenu->AddSection("EdGraphSchemaAlignment", LOCTEXT("AlignHeader", "Align"));
						SubMenuSection.AddMenuEntry(FGraphEditorCommands::Get().AlignNodesTop);
						SubMenuSection.AddMenuEntry(FGraphEditorCommands::Get().AlignNodesMiddle);
						SubMenuSection.AddMenuEntry(FGraphEditorCommands::Get().AlignNodesBottom);
						SubMenuSection.AddMenuEntry(FGraphEditorCommands::Get().AlignNodesLeft);
						SubMenuSection.AddMenuEntry(FGraphEditorCommands::Get().AlignNodesCenter);
						SubMenuSection.AddMenuEntry(FGraphEditorCommands::Get().AlignNodesRight);
						SubMenuSection.AddMenuEntry(FGraphEditorCommands::Get().StraightenConnections);
					}

					{
						FToolMenuSection& SubMenuSection = InMenu->AddSection("EdGraphSchemaDistribution", LOCTEXT("DistributionHeader", "Distribution"));
						SubMenuSection.AddMenuEntry(FGraphEditorCommands::Get().DistributeNodesHorizontally);
						SubMenuSection.AddMenuEntry(FGraphEditorCommands::Get().DistributeNodesVertically);
					}
				}));
		}
	}
}

void UEdGraphNode_ImageComment::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
	if (NodeType == ImageCommentNodeType::Material)
	{
		if (PropertyChangedEvent.Property)
		{
			const FName PropertyName = PropertyChangedEvent.Property->GetFName();
			if (PropertyName == FName(TEXT("NodeComment")))
			{
				if (MaterialExpressionComment)
				{
					MaterialExpressionComment->Modify();
					ImageCommentUtilities::SetCommentUserText(MaterialExpressionComment,NodeComment);
				}
			}
		}
	}
	//节点编辑属性触发, 材质里只有改comment会被调用, 且是被rename主动调用的
}

void UEdGraphNode_ImageComment::PostCopyNode()
{
	//没被触发过?
	ResetMaterialExpressionOwner();
}

void UEdGraphNode_ImageComment::PostDuplicate(bool bDuplicateForPIE)
{
	Super::PostDuplicate(bDuplicateForPIE);
	if(NodeType == ImageCommentNodeType::K2) return;
	//没被触发过?
	if (!bDuplicateForPIE)
	{
		CreateNewGuid();
	}
}

void UEdGraphNode_ImageComment::PrepareForCopying()
{
	Super::PrepareForCopying();
	if(NodeType == ImageCommentNodeType::K2) return;
	if (MaterialExpressionComment)
	{
		// Temporarily take ownership of the MaterialExpression, so that it is not deleted when cutting
		MaterialExpressionComment->Rename(NULL, this, REN_DontCreateRedirectors);
	}
	////在复制时会被触发, 其中事件导致编译后会删除原节点, 可以改到删除中
	///
	//Debug::Print(FString("PrepareForCopying"));
}

void UEdGraphNode_ImageComment::PostEditImport()
{
	Super::PostEditImport();
	if(NodeType == ImageCommentNodeType::K2) return;
	ResetMaterialExpressionOwner();
	//在粘贴时会被触发, 其中事件没有什么效果, 可以改为新建comment
	//Debug::Print(FString("PostEditImport"));
}

bool UEdGraphNode_ImageComment::CanCreateUnderSpecifiedSchema(const UEdGraphSchema* Schema) const
{
	return NodeType == ImageCommentNodeType::K2 ? Super::CanCreateUnderSpecifiedSchema(Schema) : Schema->IsA(UMaterialGraphSchema::StaticClass());
}

void UEdGraphNode_ImageComment::BeginDestroy()
{
	Super::BeginDestroy();
	//delete时并不调用
}

TSharedPtr<SGraphNode> UEdGraphNode_ImageComment::CreateVisualWidget()
{
	//return Super::CreateVisualWidget();
	return SNew(SGraphNode_ImageComment, this);
}

/*
TSharedPtr<SWidget> UEdGraphNode_ImageComment::CreateNodeImage() const
{
	//return Super::CreateNodeImage();
	return SNew(SImage)
			.Image(GetBackgroundBrush());
			//.ColorAndOpacity(FLinearColor::White);
		
}*/

void UEdGraphNode_ImageComment::UpdateImageSize()
{
	CachedImageSize = ImageCommentUtilities::ReadImageSize(BackgroundImagePath);
}

void UEdGraphNode_ImageComment::ResetMaterialExpressionOwner()
{
	if (MaterialExpressionComment)
	{
		// Ensures MaterialExpression is owned by the Material or Function
		UMaterialGraph* MaterialGraph = CastChecked<UMaterialGraph>(GetGraph());
		UObject* ExpressionOuter = MaterialGraph->Material;
		if (MaterialGraph->MaterialFunction)
		{
			ExpressionOuter = MaterialGraph->MaterialFunction;
		}
		MaterialExpressionComment->Rename(NULL, ExpressionOuter, REN_DontCreateRedirectors);

		// Set up the back pointer for newly created material nodes
		MaterialExpressionComment->GraphNode = this;
	}
}


#undef LOCTEXT_NAMESPACE
