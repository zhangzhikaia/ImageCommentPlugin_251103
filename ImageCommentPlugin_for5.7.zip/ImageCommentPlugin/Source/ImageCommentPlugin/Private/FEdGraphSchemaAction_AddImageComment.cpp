﻿// Copyright lurongjiu 2025. All Rights Reserved.

#include "FEdGraphSchemaAction_AddImageComment.h"

#include "DebugHelper_ImageComment.h"
#include "EdGraphNode_ImageComment.h"
#include "EdGraphSchema_Niagara.h"
#include "MaterialEditorUtilities.h"
#include "Kismet2/KismetEditorUtilities.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "MaterialGraph/MaterialGraph.h"
#include "Materials/MaterialExpressionComment.h"

UEdGraphNode* FEdGraphSchemaAction_AddImageComment_K2::PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin,const FVector2D Location, bool bSelectNewNode)
{
	// Add menu item for creating comment boxes
	UEdGraphNode_ImageComment* CommentTemplate = NewObject<UEdGraphNode_ImageComment>();
	//UEdGraphNode_Comment* CommentTemplate = NewObject<UEdGraphNode_Comment>();
	
	UBlueprint* Blueprint = FBlueprintEditorUtils::FindBlueprintForGraph(ParentGraph);

	FVector2D SpawnLocation = Location;

	FSlateRect Bounds;
	if ((Blueprint != nullptr) && FKismetEditorUtilities::GetBoundsForSelectedNodes(Blueprint, Bounds, 50.0f))
	{
		CommentTemplate->SetBounds(Bounds);
		SpawnLocation.X = CommentTemplate->NodePosX;
		SpawnLocation.Y = CommentTemplate->NodePosY;
	}
	//设置为蓝图类图表节点
	CommentTemplate->NodeType = ImageCommentNodeType::K2;
	
	UEdGraphNode* NewNode = FEdGraphSchemaAction_NewNode::SpawnNodeFromTemplate<UEdGraphNode_ImageComment>(ParentGraph, CommentTemplate, SpawnLocation, bSelectNewNode);
	//UEdGraphNode* NewNode = FEdGraphSchemaAction_NewNode::SpawnNodeFromTemplate<UEdGraphNode_Comment>(ParentGraph, CommentTemplate, SpawnLocation, bSelectNewNode);
	
	// Update Analytics for these nodes
	FBlueprintEditorUtils::AnalyticsTrackNewNode( NewNode );

	// Mark Blueprint as structurally modified since
	// UK2Node_Comment::NodeCausesStructuralBlueprintChange used to return true
	FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(Blueprint);

	return NewNode;
}

UEdGraphNode* FMaterialGraphSchemaAction_AddImageComment::PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin,const FVector2D Location, bool bSelectNewNode)
{
	//事务管理器，用于支持撤销/重做功能(和源码一样)
	const FScopedTransaction Transaction(NSLOCTEXT("ImageComment", "MaterialEditorNewImageComment", "Material Editor: New Image Comment") );
	
	//创建一个原生的MaterialExpressionComment,用于储存操作真正的节点. 这里已经创建好一个原生comment
	if (UMaterialExpressionComment* ExpressionComment = FMaterialEditorUtilities::CreateNewMaterialExpressionComment(ParentGraph, Location))
	{
		//创建image comment节点
		FGraphNodeCreator<UEdGraphNode_ImageComment> NodeCreator(*ParentGraph);
		UEdGraphNode_ImageComment* ImageComment = NodeCreator.CreateUserInvokedNode(true);

		//初始化为材质节点
		ImageComment->NodeType = ImageCommentNodeType::Material;
		ImageComment->MaterialExpressionComment = ExpressionComment;
		ImageComment->bIsNewMaterialNode = true;
		
		NodeCreator.Finalize();

		return ImageComment;
	}

	return NULL;
}

UEdGraphNode* FMaterialGraphSchemaAction_LoadImageComment::PerformAction(class UEdGraph* ParentGraph,UEdGraphPin* FromPin, const FVector2D Location, bool bSelectNewNode)
{
	//const FScopedTransaction Transaction(NSLOCTEXT("ImageComment", "MaterialEditorLoadImageComment", "Material Editor: Load Image Comment") );
	//创建image comment节点并替换
	if(MaterialExpressionComment.IsValid())
	{
		FGraphNodeCreator<UEdGraphNode_ImageComment> NodeCreator(*ParentGraph);
		UEdGraphNode_ImageComment* ImageComment = NodeCreator.CreateNode(false);
	
		ImageComment->NodeType = ImageCommentNodeType::Material;
		ImageComment->MaterialExpressionComment = MaterialExpressionComment.Get();
		ImageComment->bIsNewMaterialNode = false;

		ImageComment->BackgroundImagePath = CacheImagePath;
		ImageComment->UpdateImageSize();
	
		NodeCreator.Finalize();
	
		return ImageComment;
	}
	return NULL;
}

UEdGraphNode* FNiagaraSchemaAction_NewImageComment::PerformAction(class UEdGraph* ParentGraph, UEdGraphPin* FromPin,const FVector2D Location, bool bSelectNewNode)
{
	// Add menu item for creating comment boxes
	UEdGraphNode_ImageComment* CommentTemplate = NewObject<UEdGraphNode_ImageComment>();

	FVector2D SpawnLocation = Location;
	
	if(GraphEditor)
	{
		FSlateRect Bounds;
		if (GraphEditor->GetBoundsForSelectedNodes(Bounds, 50.0f))
		{
			CommentTemplate->SetBounds(Bounds);
			SpawnLocation.X = CommentTemplate->NodePosX;
			SpawnLocation.Y = CommentTemplate->NodePosY;
		}
	}

	CommentTemplate->bCommentBubbleVisible_InDetailsPanel = false;
	CommentTemplate->bCommentBubbleVisible = false; 
	CommentTemplate->bCommentBubblePinned = false;

	CommentTemplate->NodeType = ImageCommentNodeType::K2;

	UEdGraphNode* NewNode = FNiagaraSchemaAction_NewNode::SpawnNodeFromTemplate<UEdGraphNode_Comment>(ParentGraph, CommentTemplate, SpawnLocation, bSelectNewNode);
	return NewNode;
}
	
